module.exports = {
  singleQuote: false,
  trailingComma: "all",
};