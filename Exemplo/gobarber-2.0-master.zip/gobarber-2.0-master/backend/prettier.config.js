module.exports = {
  singleQuote: false,
  trailingComma: "all",
  arrowParens: "avoid"
};
