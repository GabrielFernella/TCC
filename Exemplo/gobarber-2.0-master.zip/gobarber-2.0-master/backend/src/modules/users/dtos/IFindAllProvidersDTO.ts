export default interface IFindAllProvidersDTO {
  expect_user_id?: string;
}
