export default interface IFindAllInMonthFromProvider {
  provider_id: string;
  month: number;
  year: number;
}
