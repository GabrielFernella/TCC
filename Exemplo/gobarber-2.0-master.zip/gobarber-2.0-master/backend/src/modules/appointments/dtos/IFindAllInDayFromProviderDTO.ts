export default interface IFindAllInDayFromProvider {
  provider_id: string;
  day: number;
  month: number;
  year: number;
}
